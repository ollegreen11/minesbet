import React, { Component } from 'react'

import './404.css'

class NotFound extends Component {

  render() {
    return (
      <div className="NotFound">
        <p>Page Not Found</p>
      </div>
    )
  }

}

export default NotFound
