import React, { Component } from 'react'

class User extends Component {

  render() {
    return null
  }

}

export default User
