import { default as CoinflipManager } from './coinflipManager'

const coinflip = new CoinflipManager()

export { coinflip }
