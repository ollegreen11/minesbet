export { coinflip } from './coinflip/coinflip'
export { bot } from './bot/botManager'
export { jackpot } from './jackpot/jackpot'
export { rake } from './rake/rake'
