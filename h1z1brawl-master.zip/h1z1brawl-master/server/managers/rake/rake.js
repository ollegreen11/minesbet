import { RakeManager } from './rakeManager'

const rake = new RakeManager()

export { rake }
