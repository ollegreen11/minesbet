import { JackpotManager } from './jackpotManager'

const jackpot = new JackpotManager()

export { jackpot }
